# -*- coding: utf8 -*-
import bs
import bsInternal
import datetime
import time
import os.path
from thread import start_new_thread
import handle
import subprocess
import random
import getPermissionsHashes as gph
import settings

chatMuted = False
try:
    from profanity import profanity
    _profanity = True
except:
    print 'profanity not present'
    _profanity = False

mutedIDs = []
filter_words =                                                                                                                                         ['2g1c', '2 girls 1 cup', 'acrotomophilia', 'alabama hot pocket', 'alaskan pipeline', 'anal', 'anilingus', 'anus', 'apeshit', 'arsehole', 'ass', 'asshole', 'assmunch', 'auto erotic', 'autoerotic', 'babeland', 'baby batter', 'baby juice', 'ball gag', 'ball gravy', 'ball kicking', 'ball licking', 'ball sack', 'ball sucking', 'bangbros', 'bareback', 'barely legal', 'barenaked', 'bastard', 'bastardo', 'bastinado', 'bbw', 'bdsm', 'beaner', 'beaners', 'beaver cleaver', 'beaver lips', 'bestiality', 'big black', 'big breasts', 'big knockers', 'big tits', 'bimbos', 'birdlock', 'bitch', 'bitches', 'black cock', 'blonde action', 'blonde on blonde action', 'blowjob', 'blow job', 'blow your load', 'blue waffle', 'blumpkin', 'bollocks', 'bondage', 'boner', 'boob', 'boobs', 'booty call', 'brown showers', 'brunette action', 'bukkake', 'bulldyke', 'bullet vibe', 'bullshit', 'bung hole', 'bunghole', 'busty', 'butt', 'buttcheeks', 'butthole', 'camel toe', 'camgirl', 'camslut', 'camwhore', 'carpet muncher', 'carpetmuncher', 'chocolate rosebuds', 'circlejerk', 'cleveland steamer', 'clit', 'clitoris', 'clover clamps', 'clusterfuck', 'cock', 'cocks', 'coprolagnia', 'coprophilia', 'cornhole', 'coon', 'coons', 'creampie', 'cum', 'cumming', 'cunnilingus', 'cunt', 'darkie', 'date rape', 'daterape', 'deep throat', 'deepthroat', 'dendrophilia', 'dick', 'dildo', 'dingleberry', 'dingleberries', 'dirty pillows', 'dirty sanchez', 'doggie style', 'doggiestyle', 'doggy style', 'doggystyle', 'dog style', 'dolcett', 'domination', 'dominatrix', 'dommes', 'donkey punch', 'double dong', 'double penetration', 'dp action', 'dry hump', 'dvda', 'eat my ass', 'ecchi', 'ejaculation', 'erotic', 'erotism', 'escort', 'eunuch', 'faggot', 'fecal', 'felch', 'fellatio', 'feltch', 'female squirting', 'femdom', 'figging', 'fingerbang', 'fingering', 'fisting', 'foot fetish', 'footjob', 'frotting', 'fuck', 'fuck buttons', 'fuckin', 'fucking', 'fucktards', 'fudge packer', 'fudgepacker', 'futanari', 'gang bang', 'gay sex', 'genitals', 'giant cock', 'girl on', 'girl on top', 'girls gone wild', 'goatcx', 'goatse', 'god damn', 'gokkun', 'golden shower', 'goodpoop', 'goo girl', 'goregasm', 'grope', 'group sex', 'g-spot', 'guro', 'hand job', 'handjob', 'hard core', 'hardcore', 'hentai', 'homoerotic', 'honkey', 'hooker', 'hot carl', 'hot chick', 'how to kill', 'how to murder', 'huge fat', 'humping', 'incest', 'intercourse', 'jack off', 'jail bait', 'jailbait', 'jelly donut', 'jerk off', 'jigaboo', 'jiggaboo', 'jiggerboo', 'jizz', 'juggs', 'kike', 'kinbaku', 'kinkster', 'kinky', 'knobbing', 'leather restraint', 'leather straight jacket', 'lemon party', 'lolita', 'lovemaking', 'make me come', 'male squirting', 'masturbate', 'menage a trois', 'milf', 'missionary position', 'motherfucker', 'mound of venus', 'mr hands', 'muff diver', 'muffdiving', 'nambla', 'nawashi', 'negro', 'neonazi', 'nigga', 'nigger', 'nig nog', 'nimphomania', 'nipple', 'nipples', 'nsfw images', 'nude', 'nudity', 'nympho', 'nymphomania', 'octopussy', 'omorashi', 'one cup two girls', 'one guy one jar', 'orgasm', 'orgy', 'paedophile', 'paki', 'panties', 'panty', 'pedobear', 'pedophile', 'pegging', 'penis', 'phone sex', 'piece of shit', 'pissing', 'piss pig', 'pisspig', 'playboy', 'pleasure chest', 'pole smoker', 'ponyplay', 'poof', 'poon', 'poontang', 'punany', 'poop chute', 'poopchute', 'porn', 'porno', 'pornography', 'prince albert piercing', 'pthc', 'pubes', 'pussy', 'queaf', 'queef', 'quim', 'raghead', 'raging boner', 'rape', 'raping', 'rapist', 'rectum', 'reverse cowgirl', 'rimjob', 'rimming', 'rosy palm', 'rosy palm and her 5 sisters', 'rusty trombone', 'sadism', 'santorum', 'scat', 'schlong', 'scissoring', 'semen', 'sex', 'sexo', 'sexy', 'shaved beaver', 'shaved pussy', 'shemale', 'shibari', 'shit', 'shitblimp', 'shitty', 'shota', 'shrimping', 'skeet', 'slanteye', 'slut', 's&m', 'smut', 'snatch', 'snowballing', 'sodomize', 'sodomy', 'spic', 'splooge', 'splooge moose', 'spooge', 'spread legs', 'spunk', 'strap on', 'strapon', 'strappado', 'strip club', 'style doggy', 'suck', 'sucks', 'suicide girls', 'sultry women', 'swastika', 'swinger', 'tainted love', 'taste my', 'tea bagging', 'threesome', 'throating', 'tied up', 'tight white', 'tit', 'tits', 'titties', 'titty', 'tongue in a', 'topless', 'tosser', 'towelhead', 'tranny', 'tribadism', 'tub girl', 'tubgirl', 'tushy', 'twat', 'twink', 'twinkie', 'two girls one cup', 'undressing', 'upskirt', 'urethra play', 'urophilia', 'vagina', 'venus mound', 'vibrator', 'violet wand', 'vorarephilia', 'voyeur', 'vulva', 'wank', 'wetback', 'wet dream', 'white power', 'wrapping men', 'wrinkled starfish', 'xxx', 'yaoi', 'yellow showers', 'yiffy', 'zoophilia', 'ðŸ–•', 'aand', 'aandu', 'balatkar', 'beti chod', 'bhadva', 'bhadve', 'bhandve', 'bhootni ke', 'bhosad', 'bhosadi ke', 'boobe', 'chakke', 'chinaal', 'chinki', 'chod', 'chodu', 'chodu bhagat', 'chooche', 'choochi', 'choot', 'choot ke baal', 'chootia', 'chootiya', 'chuche', 'chuchi', 'chudai khanaa', 'chudan chudai', 'chut', 'chut ke baal', 'chut ke dhakkan', 'chut maarli', 'chutad', 'chutadd', 'chutan', 'chutia', 'chutiya', 'gaand', 'gaandfat', 'gaandmasti', 'gaandufad', 'gandu', 'gashti', 'gasti', 'ghassa', 'ghasti', 'harami', 'haramzade', 'hawas', 'hawas ke pujari', 'hijda', 'hijra', 'jhant', 'jhant chaatu', 'jhant ke baal', 'jhantu', 'kamine', 'kaminey', 'kanjar', 'kutta', 'kutta kamina', 'kutte ki aulad', 'kutte ki jat', 'kuttiya', 'loda', 'lode', 'lavde', 'lauda', 'lodu', 'lund', 'lund choos', 'lund khajoor', 'lundtopi', 'lundure', 'maa ki chut', 'maal', 'madar chod', 'mooh mein le', 'mutth', 'najayaz', 'najayaz aulaad', 'najayaz paidaish', 'paki', 'pataka', 'patakha', 'raand', 'randi', 'saala', 'saala kutta', 'saali kutti', 'saali randi', 'suar', 'suar ki aulad', 'tatte', 'tatti', 'teri maa ka bhosada', 'teri maa ka boba chusu', 'teri maa ki chut', 'tharak', 'tharki', 'madarchod', 'lawde', 'lawda', 'bc', 'mc',]
if _profanity:
    profanity.load_words(filter_words)

def _chatFilter(msg, clientID):
    msg = bs.uni(msg.rstrip())
    if clientID == -1:
        return msg
    
    if settings.spamProtection:
        import spamProtection
        if spamProtection.checkSpam(clientID) == False:
            return None
    m = msg.split(' ')[0]
    a = msg.split(' ')[1:]
    if m in ['/pvtmsg','/dm','/pm']:
        try:
            def getPlayerFromMention(mention):
                for i in bsInternal._getForegroundHostActivity().players:
                    if i.getName().lower().find(mention.lower()) != -1:
                        return i
                else:
                    return None
            def getPlayerFromClientID(clientID):
                for i in bsInternal._getForegroundHostActivity().players:
                    if i.getInputDevice().getClientID() == clientID:
                        return i
                else:
                    return None
            if a[0].isdigit():
                for player in bsInternal._getForegroundHostActivity().players:
                    if a[0] == str(bsInternal._getForegroundHostSession().players.index(player)):
                        fr = getPlayerFromClientID(clientID)
                        what = ' '.join(a[1:]).encode('utf-8')
                        to = player
                        bs.screenMessage('Private Message Has Been Sent To {}: {}'.format(to.getName(True).encode('utf-8'),what),transient=True,clients=[fr.getInputDevice().getClientID()],color=(0,2,2))
                        bs.screenMessage('Private Message From {}: {}'.format(fr.getName(True).encode('utf-8'),what),transient=True,clients=[to.getInputDevice().getClientID()],color=(0,2,2))
            else:
                to = getPlayerFromMention(a[0])
                fr = getPlayerFromClientID(clientID)
                what = ' '.join(a[1:])
                bs.screenMessage('Private Message Has Been Sent To {}: {}'.format(to.getName(True).encode('utf-8'),what),transient=True,clients=[fr.getInputDevice().getClientID()],color=(0,2,2))
                bs.screenMessage('Private Message From {}: {}'.format(fr.getName(True).encode('utf-8'),what),transient=True,clients=[to.getInputDevice().getClientID()],color=(0,2,2))
            return None
        except Exception as e:
            bs.screenMessage('Format: /pvtmsg <name> <message>')
            print e
    r = bsInternal._getGameRoster()
    for a in r:
        if a['clientID'] == clientID:
            if len(a['players']) > 0:
                name = a['players'][0]['name']
                player = handle.getPlayerFromNick(name)
                account_id = '-' if player is None else player.get_account_id()
                playerInGame = True
            else:
                name = (a['displayString'])
                account_id = '-'
                playerInGame = False
            break
    else:
        print r
        return None
    name = bs.uni(name)
    if not playerInGame:
        bs.screenMessage('Why waiting outside?',
                             color=(1, 0.5, 0.5),
                             transient=True,
                             clients=[clientID])
        return None
    if msg.startswith('/'):
        sender = None
        import chatCmd
        chatCmd.cmd(msg,clientID)
        return None
    client = 'Animeboy'
    for i in bsInternal._getForegroundHostActivity().players:
        if i.getInputDevice().getClientID() == clientID:
            client = i.get_account_id()
    def checkid(client):
        if client in gph.ownerHashes:
            return True
        elif client in gph.adminHashes:
            return True
        else:
            return False
    val=checkid(client)
    if chatMuted and not val:
        bs.screenMessage('Chat is muted for some time',
                         color=(1, 0, 0),
                         clients=[clientID],
                         transient=True)
        return None
    if clientID in mutedIDs and not val:
        bs.screenMessage(
            'Owner has muted you for some time. Pro Tip: Stop Begging or Spamming',
            color=(1, 0, 0),
            clients=[clientID],
            transient=True)
        return None

    #if not '/!' in msg: start_new_thread(db.logChat,(msg, name, account_id))  #Chat Logs
    if not account_id in gph.ownerHashes:
        import re
        old_msg = msg
        clean_msg = re.sub('[^A-Za-z0-9 ]+', '', msg)
        for word in filter_words:
            if re.search(r'\b({})\b'.format(word), clean_msg, re.IGNORECASE):
                cen = ''.join(
                    random.choice(list('****')) for a in range(len(word)))
                clean_msg = re.sub(r'\b({})\b'.format(word),
                                   cen,
                                   clean_msg,
                                   flags=re.IGNORECASE)
                msg = clean_msg
        if msg != old_msg:
            import kicker
            kicker.kick(name, reason='Abuse', warn=True)
            return msg
        
    if 'admin' in msg.lower() or 'mod' in msg.lower(
    ) or 'promote' in msg.lower():
        for i in ['pls', 'please', 'give', 'want', 'can i']:
            if i in msg.lower():
                bs.screenMessage(
                    'Stop Begging For Admin! This Server is Self-Sufficient!',
                    color=(1, 0, 0),
                    transient=True,
                    clients=[clientID])
                import kicker
                kicker.kick(name, reason='Begging', warn=True)
                return msg
    return msg
